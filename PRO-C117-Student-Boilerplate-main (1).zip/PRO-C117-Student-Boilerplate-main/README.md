# PRO-C117-Student-Boilerplate
To complete this Project, make sure you have :
1) Downloaded all the files from this Repository
2) Created a virtual environment
3) Installed the necessary libraries like flask , pandas , Tensorflow
